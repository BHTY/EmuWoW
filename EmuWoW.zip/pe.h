#pragma once

#include <windows.h>
#include <winnt.h>

VOID WritePESections(PBYTE ImageBase, PBYTE pData, PIMAGE_SECTION_HEADER sections, WORD nSections);
LPVOID MapImageIntoMemory(LPCSTR lpLibFileName);
HMODULE LoadNativeLibrary(LPCSTR lpLibFileName);
FARPROC EmuGetProcAddress(LPVOID module, LPCSTR lpProcName);
PVOID EmuLoadModule(LPCSTR lpLibFileName);